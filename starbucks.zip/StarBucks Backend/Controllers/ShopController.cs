using Microsoft.AspNetCore.Mvc;
using StarBucks_Backend.Models;
using StarBucks_Backend.Services;

namespace StarBucks_Backend.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        public IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }
        
        [HttpGet]
        public ActionResult<ApiResponse<IEnumerable<Products>>> Get()
        {
            try
            {
                var products = _productService.GetProducts();
                var response = new ApiResponse<IEnumerable<Products>>
                {
                    Status = "success",
                    Data = products,
                    Count = products.Count(),
                    Error = null
                };
                return Ok(response);
            }
            catch(Exception ex)
            {
                var response = new ApiResponse<IEnumerable<Products>>
                {
                    Status = "fail",
                    Data = null,
                    Error = ex.Message
                };
                return StatusCode(500,response);
            }            
        }

        [HttpGet("{id}",Name="GetProductById")]
        public ActionResult<ApiResponse<Products>> GetById(int id)
        {
            try
            {
                var product = _productService.GetProductById(id);
                if (product != null)
                {

                    var response = new ApiResponse<Products>
                    {
                        Status = "success",
                        Data = product,
                        Error = null
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new ApiResponse<Products>
                    {
                        Status = "fail",
                        Data = null,
                        Error = $"Product with ID {id} not found."
                    };
                    return NotFound(response);
                }
                
            }
            catch (Exception ex)
            {
                var response = new ApiResponse<Products>
                {
                    Status = "fail",
                    Data = null,
                    Error =ex.Message
                };
                return StatusCode(500, response);
            }
        }

        [HttpPost(Name ="AddProduct")]
        public IActionResult AddProduct(Products product)
        {
            try
            {
                _productService.AddProducts(product);
                var response = new ApiResponse<Products>
                {
                    Status = "success",
                    Data = product,
                    Error = null
                };
                return CreatedAtAction(nameof(GetById), new { id = product.ID }, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }


        [HttpPost("BuyProduct")]
        public ActionResult<ApiResponse<string>> BuyProductById(int ProductId, int Quantity)
        {
            try
            {
                var result = _productService.BuyProduct(ProductId, Quantity);

                if (result == "Purchase successful")
                {
                    var response = new ApiResponse<string>
                    {
                        Status = "success",
                        Data = result,
                        Count = null,
                        Error = null
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new ApiResponse<string>
                    {
                        Status = "fail",
                        Data = null,
                        Count = null,
                        Error = result
                    };
                    return BadRequest(response);
                }
            }
            catch (Exception ex)
            {
                var response = new ApiResponse<string>
                {
                    Status = "fail",
                    Data = null,
                    Count = null,
                    Error = ex.Message
                };
                return StatusCode(500, response);
            }
        }
    }

}
